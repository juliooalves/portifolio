"use client"

import dynamic from "next/dynamic"

const LaptopScene = dynamic(() => import("@/components/laptop-scene"), {
  ssr: false,
  loading: () => (
    <div className="w-full h-screen bg-[#0a0a14] flex items-center justify-center">
      <div className="text-[#53d8fb] font-mono text-sm animate-pulse">
        Loading 3D Scene...
      </div>
    </div>
  ),
})

export default function Page() {
  return <LaptopScene />
}
